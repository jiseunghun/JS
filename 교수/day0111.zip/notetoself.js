window.onload=function(){
    button=document.getElementById("add_button");
    button.onclick=createSticky;
    
    //기존의 스티키 노트를 추가
    var stickiesArray=getStickiesArray();
    for(var i=0;i<stickiesArray.length;i++){
                  var key=stickiesArray[i];
                  var value=JSON.parse(localStorage[key]);
                  addStickyToDOM(key, value);
    }
    
    //전체 삭제 버튼
    clearButton=document.getElementById("clear_button");
    clearButton.onclick=clearStickyNotes;
}

function clearStickyNotes(){
    var ans=confirm("정말 전체노트를 삭제하려면 확인을 눌러주세요");
    if(ans!=1)
                  return false;
    //전체 스토리지내용 삭제..문제점: 다른 로컬스토리지 내용도 모두 삭제됨
    //그래서 해당 스티키노트에 관한 스토리지만 삭제하는게 좋음
    //localStorage.clear();
    var stickiesArray=getStickiesArray();
    if(stickiesArray){
                  for(var i=0;i<stickiesArray.length;i++){
                               key=stickiesArray[i];
                               localStorage.removeItem(key);
                               }
                  localStorage.removeItem("stickiesArray");
    }
    //---------------------
    var stickyList=document.getElementById("stickies");//ul tag
    var stickies=stickyList.childNodes;//li tag들
    for(var i=stickies.length-1;i>=0;i--){
                  stickyList.removeChild(stickies[i]);
    }
    //스티키 배열을 초기화
    var stickiesArray=getStickiesArray();  	
}

//스티키 노트 추가
function createSticky(){
    var stickiesArray=getStickiesArray();
    //스티커에 들어갈 내용
    var value=document.getElementById("note_text").value;
    //스티커 색상
    var colorSelectObj=document.getElementById("note_color");
    var index=colorSelectObj.selectedIndex;
    var color=colorSelectObj[index].value;
    
    //JSON 으로 value와 color가 유지되는 스티키 노트 생성
    var currentDate=new Date();
    var key="sticky_"+currentDate.getTime();
    var stickyObj={
                               "value":value,
                               "color":color
    };
    //JSON.stringify:JSON오브젝트를 String 형태로 변환해주는 함수
    localStorage.setItem(key,JSON.stringify(stickyObj));
    //새 스티키 노트를 배열에 추가하고 localStorage에 저장된 notes 배열을 업데이트함
    stickiesArray.push(key);
    localStorage.setItem("stickiesArray",JSON.stringify(stickiesArray));
    addStickyToDOM(key,stickyObj);
}

function getStickiesArray(){
    var stickiesArray=localStorage.getItem("stickiesArray");
    if(!stickiesArray){
                  stickiesArray=[];
                  localStorage.setItem("stickiesArray",JSON.stringify(stickiesArray));
    }else{
                  stickiesArray=JSON.parse(stickiesArray);
    }
    return stickiesArray;  	
}

function addStickyToDOM(key,stickyObj){
    var stickies=document.getElementById("stickies");
    var sticky=document.createElement("li");
    
    //스티키 배열에 저장된 아이디로 찾을수 있게
    //id 속성에 key 값을 지정
    sticky.setAttribute("id", key);
    //stickyObj의 color를 이용해서 css배경색 스타일을 지정
    sticky.style.backgroundColor=stickyObj.color;
    
    var span=document.createElement("span");
    span.setAttribute("class", "sticky");
    
    //stickyObj 의 value 를 이용해서 스티키노트의 내용을 할당
    span.innerHTML=stickyObj.value;
    
    //모든것을 DOM 에 추가
    sticky.appendChild(span);
    stickies.appendChild(sticky);
    
    //스티키 노트를 클릭하면 삭제되도록 이벤트 리스너 붙임
    sticky.onclick=deleteSticky;
}
//스티키 노트 클릭시 삭제하는 함수
function deleteSticky(e){
    var ans=confirm("정말 삭제하려면 확인을 눌러주세요");
    if(ans!=1)
                  return false;
    //이벤트가 발생한 객체의 아이디
    var key=e.target.id;
    if(e.target.tagName.toLowerCase()=="span"){
                  key=e.target.parentNode.id;
    }
    var stickiesArray=getStickiesArray();
    if(stickiesArray){
                  for(var i=0;i<stickiesArray.length;i++){
                               if(key==stickiesArray[i]){
                                            stickiesArray.splice(i,1);
                               }
                  }
                  localStorage.removeItem(key);
                  localStorage.setItem("stickiesArray",JSON.stringify(stickiesArray));
                  removeStickyFromDOM(key);
    }
}

function removeStickyFromDOM(key){
    var sticky=document.getElementById(key);
    sticky.parentNode.removeChild(sticky);
}
